﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

class Program
{
    static void Main(string[] args)
    {
        TcpListener server = null;
        try
        {
            // Указываем порт для прослушивания
            int port = 8888;
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");

            server = new TcpListener(localAddr, port);
            server.Start();

            Console.WriteLine("Ожидание подключений...");

            // Принимаем первого клиента
            TcpClient client1 = server.AcceptTcpClient();
            Console.WriteLine("Первый клиент подключен!");

            // Создаем для него поток для обмена данными
            NetworkStream stream1 = client1.GetStream();

            // Отправляем первому клиенту сообщение о подключении
            string connectMessage1 = "Вы подключены к серверу. Ожидайте второго игрока...";
            byte[] connectMessageData1 = Encoding.UTF8.GetBytes(connectMessage1);
            stream1.Write(connectMessageData1, 0, connectMessageData1.Length);

            // Принимаем второго клиента
            TcpClient client2 = server.AcceptTcpClient();
            Console.WriteLine("Второй клиент подключен!");

            // Создаем для него поток для обмена данными
            NetworkStream stream2 = client2.GetStream();

            // Отправляем второму клиенту сообщение о подключении
            string connectMessage2 = "Вы подключены к серверу. Игра начинается!";
            byte[] connectMessageData2 = Encoding.UTF8.GetBytes(connectMessage2);
            stream2.Write(connectMessageData2, 0, connectMessageData2.Length);

            // Запускаем игру между клиентами
            PlayGame(stream1, stream2);
        }
        catch (SocketException e)
        {
            Console.WriteLine("SocketException: " + e);
        }
        finally
        {
            server.Stop(); // Останавливаем сервер
        }

        Console.WriteLine("\nСервер остановлен.");
        Console.ReadLine();
    }

    static void PlayGame(NetworkStream stream1, NetworkStream stream2)
    {
        Random rnd = new Random();

        int totalPlayer1 = 0;
        int totalPlayer2 = 0;

        bool player1Passed = false;
        bool player2Passed = false;

        while (true)
        {
            if (!player1Passed)
            {
                totalPlayer1 = PlayTurn(stream1, stream2, totalPlayer1, "Первый", out player1Passed);
                if (totalPlayer1 >= 21 || (player1Passed && player2Passed))
                    break;
            }

            if (!player2Passed)
            {
                totalPlayer2 = PlayTurn(stream2, stream1, totalPlayer2, "Второй", out player2Passed);
                if (totalPlayer2 >= 21 || (player1Passed && player2Passed))
                    break;
            }
        }

        // Оба игрока пасуют или один из них достиг максимального счета
        string resultMessage = GetWinnerMessage(totalPlayer1, totalPlayer2);
        byte[] resultData = Encoding.UTF8.GetBytes(resultMessage);
        stream1.Write(resultData, 0, resultData.Length);
        stream2.Write(resultData, 0, resultData.Length);
    }



    static int PlayTurn(NetworkStream currentPlayerStream, NetworkStream opponentStream, int totalPoints, string playerName, out bool playerPassed)
    {
        Random rnd = new Random();

        byte[] rollRequestData = Encoding.UTF8.GetBytes($"Ходит {playerName} игрок. Бросить кость? (да/нет): ");
        currentPlayerStream.Write(rollRequestData, 0, rollRequestData.Length);

        byte[] responseData = new byte[1024]; // Увеличиваем размер буфера
        int bytesRead = currentPlayerStream.Read(responseData, 0, responseData.Length);
        string response = Encoding.UTF8.GetString(responseData, 0, bytesRead);

        if (response.Trim().ToLower() == "да")
        {
            int roll = rnd.Next(1, 7); // бросаем кость
            totalPoints += roll;

            string message = $"Вы выбросили: {roll}. Текущий счёт: {totalPoints} из 21";
            byte[] messageData = Encoding.UTF8.GetBytes(message);
            currentPlayerStream.Write(messageData, 0, messageData.Length);

            string opponentMessage = $"Соперник выбросил: {roll}. Его текущий счёт: {totalPoints} из 21";
            byte[] opponentMessageData = Encoding.UTF8.GetBytes(opponentMessage);
            opponentStream.Write(opponentMessageData, 0, opponentMessageData.Length);

            playerPassed = totalPoints >= 21;
        }
        else if (response.Trim().ToLower() == "нет")
        {
            currentPlayerStream.Write(Encoding.UTF8.GetBytes($"Вы пасуете. Текущий счёт: {totalPoints} из 21"), 0, Encoding.UTF8.GetBytes($"Вы пасуете. Текущий счёт: {totalPoints} из 21").Length);
            playerPassed = true;
        }
        else
        {
            playerPassed = false;
        }

        return totalPoints;
    }


    static string GetWinnerMessage(int totalPoints1, int totalPoints2)
    {
        if (totalPoints1 > 21 && totalPoints2 > 21)
        {
            return "Результат игры: Оба игрока проиграли.";
        }
        else if (totalPoints1 <= 21 && totalPoints2 <= 21)
        {
            if (totalPoints1 == totalPoints2)
            {
                return "Результат игры: Ничья.";
            }
            else if (totalPoints1 > totalPoints2)
            {
                return "Результат игры: Победил первый игрок!";
            }
            else
            {
                return "Результат игры: Победил второй игрок!";
            }
        }
        else
        {
            if (totalPoints1 > 21)
            {
                return "Результат игры: Победил второй игрок!";
            }
            else
            {
                return "Результат игры: Победил первый игрок!";
            }
        }
    }
}



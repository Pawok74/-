﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace Client2
{
    public partial class Form1 : Form
    {
        private TcpClient client; // Объект для подключения к серверу
        private NetworkStream stream; // Поток для обмена данными с сервером
        private bool isClientTurn = true; // Флаг, указывающий, чей сейчас ход
        private int totalClient = 0; // Общее количество очков клиента

        public Form1()
        {
            InitializeComponent();
            richTextBox1.KeyDown += richTextBox1_KeyDown; // Привязываем обработчик события нажатия клавиши
        }

        private void ConnectToServer()
        {
            try
            {
                // Устанавливаем соединение с сервером
                string ipAddress = textBox1.Text;
                int port = 8888;
                client = new TcpClient(ipAddress, port); // Подключаемся к серверу по указанному адресу и порту
                stream = client.GetStream(); // Получаем поток для обмена данными с сервером

                // Начинаем игру
                ReceiveMessage(); // Вызываем метод для приема сообщений от сервера
            }
            catch (SocketException e)
            {
                MessageBox.Show("Ошибка подключения к серверу: " + e.Message); // В случае ошибки подключения выводим сообщение об ошибке
            }
        }

        private async void ReceiveMessage()
        {
            try
            {
                byte[] buffer = new byte[256];
                while (true)
                {
                    int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length); // Асинхронно считываем данные из потока
                    if (bytesRead == 0)
                    {
                        MessageBox.Show("Сервер закрыл соединение."); // Выводим сообщение о закрытии соединения, если количество считанных байтов равно 0
                        break; // Выходим из цикла, если сервер закрыл соединение
                    }
                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead); // Преобразуем считанные байты в строку
                    DisplayMessage(message); // Отображаем полученное сообщение
                    if (message.Contains("Результат игры")) // Проверяем, содержит ли сообщение информацию о результате игры
                    {
                        break; // Если да, выходим из цикла
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при чтении данных: " + ex.Message); // В случае ошибки чтения данных выводим сообщение об ошибке
            }
        }

        private void SendMessage(string message)
        {
            byte[] data = Encoding.UTF8.GetBytes(message); // Преобразуем строку в байтовый массив
            stream.Write(data, 0, data.Length); // Отправляем данные на сервер
            ReceiveMessage(); // Получаем ответ от сервера
        }

        private void DisplayMessage(string message)
        {
            if (InvokeRequired)
            {
                Invoke(new Action<string>(DisplayMessage), message);
                return;
            }

            // Выводим полученное сообщение в текстовое поле
            richTextBox1.AppendText(message + Environment.NewLine);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (client != null)
                client.Close(); // Закрываем соединение с сервером при закрытии формы
        }

        private void buttonRoll_Click_1(object sender, EventArgs e)
        {
            if (isClientTurn)
            {
                string rollResponse = "да"; // Отправляем ответ серверу о согласии бросить кубик
                SendMessage(rollResponse); // Отправляем сообщение серверу
            }
        }

        private void buttonPass_Click_1(object sender, EventArgs e)
        {
            if (isClientTurn)
            {
                string rollResponse = "нет"; // Отправляем ответ серверу об отказе бросить кубик
                SendMessage(rollResponse); // Отправляем сообщение серверу
                isClientTurn = false; // Переключаем флаг на ход сервера
            }
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            ConnectToServer(); // Вызываем метод для подключения к серверу
        }

        // Обработчик события нажатия клавиши в RichTextBox
        private void richTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && !e.Shift)
            {
                // Отправить сообщение серверу, когда нажата клавиша Enter
                SendMessage(""); // Отправляем пустую строку
            }
        }

    }
}
